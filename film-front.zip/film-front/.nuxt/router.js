import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _0be074b2 = () => import('..\\pages\\query.vue' /* webpackChunkName: "pages_query" */).then(m => m.default || m)
const _1e8ba9c9 = () => import('..\\pages\\query\\_kw.vue' /* webpackChunkName: "pages_query__kw" */).then(m => m.default || m)
const _6d80d21c = () => import('..\\pages\\xseats.vue' /* webpackChunkName: "pages_xseats" */).then(m => m.default || m)
const _2409aece = () => import('..\\pages\\xseats\\_id.vue' /* webpackChunkName: "pages_xseats__id" */).then(m => m.default || m)
const _371690e8 = () => import('..\\pages\\myorder.vue' /* webpackChunkName: "pages_myorder" */).then(m => m.default || m)
const _111912d3 = () => import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */).then(m => m.default || m)
const _7326b129 = () => import('..\\pages\\register.vue' /* webpackChunkName: "pages_register" */).then(m => m.default || m)
const _75aedb3d = () => import('..\\pages\\filmItem.vue' /* webpackChunkName: "pages_filmItem" */).then(m => m.default || m)
const _c6ed9b66 = () => import('..\\pages\\filmItem\\_id.vue' /* webpackChunkName: "pages_filmItem__id" */).then(m => m.default || m)
const _37d06bd9 = () => import('..\\pages\\films.vue' /* webpackChunkName: "pages_films" */).then(m => m.default || m)
const _6ce483e8 = () => import('..\\pages\\cinemas.vue' /* webpackChunkName: "pages_cinemas" */).then(m => m.default || m)
const _603c3038 = () => import('..\\pages\\order.vue' /* webpackChunkName: "pages_order" */).then(m => m.default || m)
const _4580c232 = () => import('..\\pages\\order\\_id.vue' /* webpackChunkName: "pages_order__id" */).then(m => m.default || m)
const _35e65c59 = () => import('..\\pages\\news.vue' /* webpackChunkName: "pages_news" */).then(m => m.default || m)
const _066221f7 = () => import('..\\pages\\cinema.vue' /* webpackChunkName: "pages_cinema" */).then(m => m.default || m)
const _34570fd3 = () => import('..\\pages\\cinema\\_id.vue' /* webpackChunkName: "pages_cinema__id" */).then(m => m.default || m)
const _2a4c8093 = () => import('..\\pages\\profile.vue' /* webpackChunkName: "pages_profile" */).then(m => m.default || m)
const _d459a9ce = () => import('..\\pages\\seckill.vue' /* webpackChunkName: "pages_seckill" */).then(m => m.default || m)
const _17d60bd0 = () => import('..\\pages\\board.vue' /* webpackChunkName: "pages_board" */).then(m => m.default || m)
const _47716fbc = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/query",
			component: _0be074b2,
			name: "query",
			children: [
				{
					path: ":kw?",
					component: _1e8ba9c9,
					name: "query-kw"
				}
			]
		},
		{
			path: "/xseats",
			component: _6d80d21c,
			name: "xseats",
			children: [
				{
					path: ":id?",
					component: _2409aece,
					name: "xseats-id"
				}
			]
		},
		{
			path: "/myorder",
			component: _371690e8,
			name: "myorder"
		},
		{
			path: "/login",
			component: _111912d3,
			name: "login"
		},
		{
			path: "/register",
			component: _7326b129,
			name: "register"
		},
		{
			path: "/filmItem",
			component: _75aedb3d,
			name: "filmItem",
			children: [
				{
					path: ":id?",
					component: _c6ed9b66,
					name: "filmItem-id"
				}
			]
		},
		{
			path: "/films",
			component: _37d06bd9,
			name: "films"
		},
		{
			path: "/cinemas",
			component: _6ce483e8,
			name: "cinemas"
		},
		{
			path: "/order",
			component: _603c3038,
			name: "order",
			children: [
				{
					path: ":id?",
					component: _4580c232,
					name: "order-id"
				}
			]
		},
		{
			path: "/news",
			component: _35e65c59,
			name: "news"
		},
		{
			path: "/cinema",
			component: _066221f7,
			name: "cinema",
			children: [
				{
					path: ":id?",
					component: _34570fd3,
					name: "cinema-id"
				}
			]
		},
		{
			path: "/profile",
			component: _2a4c8093,
			name: "profile"
		},
		{
			path: "/seckill",
			component: _d459a9ce,
			name: "seckill"
		},
		{
			path: "/board",
			component: _17d60bd0,
			name: "board"
		},
		{
			path: "/",
			component: _47716fbc,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
